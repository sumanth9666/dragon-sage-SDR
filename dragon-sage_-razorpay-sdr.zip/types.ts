export interface LeadData {
  name: string | null;
  company: string | null;
  email: string | null;
  role: string | null;
  use_case: string | null;
  team_size: string | null;
  timeline: string | null;
  notes: string | null;
}

export type ConnectionState = 'disconnected' | 'connecting' | 'connected' | 'error';

export interface LogMessage {
  role: 'user' | 'system' | 'ai';
  text: string;
  timestamp: Date;
}