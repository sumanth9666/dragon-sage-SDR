import React from 'react';
import { LeadData } from '../types';

interface LeadCardProps {
  data: LeadData;
}

const LeadCard: React.FC<LeadCardProps> = ({ data }) => {
  return (
    <div className="w-full max-w-md bg-dragon-bg border border-dragon-primary/30 rounded-lg p-6 shadow-[0_0_15px_rgba(32,201,151,0.1)] mt-6 animate-pulse-slow">
      <div className="flex items-center justify-between mb-4 border-b border-dragon-primary/20 pb-2">
        <h3 className="text-xl font-bold text-dragon-primary">Lead Captured</h3>
        <span className="text-xs text-dragon-highlight bg-dragon-highlight/10 px-2 py-1 rounded">FINALIZED</span>
      </div>
      
      <div className="space-y-3 text-sm text-dragon-text">
        <div className="flex justify-between">
          <span className="text-gray-400">Name:</span>
          <span className="font-medium text-right">{data.name || '-'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400">Company:</span>
          <span className="font-medium text-right">{data.company || '-'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400">Email:</span>
          <span className="font-medium text-right">{data.email || '-'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400">Role:</span>
          <span className="font-medium text-right">{data.role || '-'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400">Team Size:</span>
          <span className="font-medium text-right">{data.team_size || '-'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400">Timeline:</span>
          <span className="font-medium text-right">{data.timeline || '-'}</span>
        </div>
        <div className="pt-2">
          <span className="text-gray-400 block mb-1">Use Case:</span>
          <p className="text-dragon-text/90 bg-black/20 p-2 rounded">{data.use_case || '-'}</p>
        </div>
      </div>
    </div>
  );
};

export default LeadCard;
