import React, { useEffect, useRef } from 'react';

interface VisualizerProps {
  isActive: boolean;
  volume: number; // 0 to 1
  mode: 'listening' | 'speaking' | 'idle';
}

const Visualizer: React.FC<VisualizerProps> = ({ isActive, volume, mode }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let time = 0;

    const render = () => {
      time += 0.05;
      
      // Clear canvas with slight transparency for trail effect
      ctx.fillStyle = 'rgba(30, 31, 34, 0.2)'; 
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      
      // Base radius calculation
      const baseRadius = mode === 'idle' ? 40 : 50 + (volume * 100);
      const color = mode === 'speaking' ? '#20C997' : (mode === 'listening' ? '#E3B341' : '#555');

      // Draw Main Orb (The Dragon's Eye)
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius, 0, Math.PI * 2);
      
      // Create gradient
      const gradient = ctx.createRadialGradient(centerX, centerY, baseRadius * 0.2, centerX, centerY, baseRadius);
      gradient.addColorStop(0, '#FFFFFF');
      gradient.addColorStop(0.4, color);
      gradient.addColorStop(1, 'transparent');
      
      ctx.fillStyle = gradient;
      ctx.fill();
      ctx.closePath();

      // Draw Rings/Ripples
      if (isActive && mode !== 'idle') {
        const numRings = 3;
        for (let i = 0; i < numRings; i++) {
          ctx.beginPath();
          const offset = (time * 2 + i * 20) % 50;
          const ringRadius = baseRadius + offset;
          const alpha = 1 - (offset / 50);
          
          ctx.strokeStyle = `rgba(${mode === 'speaking' ? '32, 201, 151' : '227, 179, 65'}, ${alpha})`;
          ctx.lineWidth = 2;
          ctx.arc(centerX, centerY, ringRadius, 0, Math.PI * 2);
          ctx.stroke();
          ctx.closePath();
        }
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => cancelAnimationFrame(animationId);
  }, [isActive, volume, mode]);

  return (
    <div className="relative flex items-center justify-center h-64 w-full">
      <canvas 
        ref={canvasRef} 
        width={300} 
        height={300} 
        className="rounded-full"
      />
      <div className="absolute bottom-4 text-dragon-text text-sm font-medium tracking-widest uppercase opacity-70">
        {mode === 'idle' ? 'Dragon Sage' : (mode === 'listening' ? 'Listening...' : 'Speaking...')}
      </div>
    </div>
  );
};

export default Visualizer;
