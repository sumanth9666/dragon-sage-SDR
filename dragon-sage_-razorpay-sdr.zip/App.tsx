import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { LeadData, ConnectionState, LogMessage } from './types';
import { SYSTEM_INSTRUCTION, leadFunctionDeclaration } from './constants';
import { createPcmBlob, decode, decodeAudioData } from './utils/audioUtils';
import Visualizer from './components/Visualizer';
import LeadCard from './components/LeadCard';

const App: React.FC = () => {
  const [connectionState, setConnectionState] = useState<ConnectionState>('disconnected');
  const [leadData, setLeadData] = useState<LeadData | null>(null);
  const [logs, setLogs] = useState<LogMessage[]>([]);
  const [volume, setVolume] = useState<number>(0);
  const [mode, setMode] = useState<'idle' | 'listening' | 'speaking'>('idle');
  const [apiKeyMissing, setApiKeyMissing] = useState(false);

  // Audio Refs
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const streamRef = useRef<MediaStream | null>(null);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);

  // Transcription Refs
  const currentInputRef = useRef('');
  const currentOutputRef = useRef('');
  
  // To handle auto-scroll of transcripts
  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  useEffect(() => {
    // Check for API Key immediately
    if (!process.env.API_KEY) {
      setApiKeyMissing(true);
    }
  }, []);

  const addLog = (role: 'user' | 'system' | 'ai', text: string) => {
    setLogs(prev => [...prev, { role, text, timestamp: new Date() }]);
  };

  const connectToGemini = async () => {
    if (!process.env.API_KEY) {
      alert("API Key is missing. Please set process.env.API_KEY.");
      return;
    }

    try {
      setConnectionState('connecting');
      addLog('system', 'Initializing audio and connection...');

      // 1. Setup Audio Contexts
      inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      // 2. Get Microphone Stream
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // 3. Initialize Gemini Client
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const config = {
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          responseModalities: [Modality.AUDIO],
          tools: [{ functionDeclarations: [leadFunctionDeclaration] }],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Fenrir' } }, // Fenrir sounds deeper/wiser
          },
        },
      };

      // 4. Connect Session
      const sessionPromise = ai.live.connect({
        model: config.model,
        config: config.config,
        callbacks: {
          onopen: () => {
            setConnectionState('connected');
            addLog('system', 'Connected to Dragon Sage.');
            startAudioInput();
          },
          onmessage: async (message: LiveServerMessage) => {
            handleServerMessage(message);
          },
          onclose: () => {
            setConnectionState('disconnected');
            addLog('system', 'Connection closed.');
            setMode('idle');
          },
          onerror: (err) => {
            console.error(err);
            setConnectionState('error');
            addLog('system', 'Error occurred.');
            disconnect();
          }
        }
      });
      
      sessionPromiseRef.current = sessionPromise;

    } catch (error) {
      console.error("Connection failed", error);
      setConnectionState('error');
      addLog('system', `Connection failed: ${error}`);
    }
  };

  const startAudioInput = () => {
    if (!inputAudioContextRef.current || !streamRef.current) return;
    
    const ctx = inputAudioContextRef.current;
    const source = ctx.createMediaStreamSource(streamRef.current);
    const processor = ctx.createScriptProcessor(4096, 1, 1);
    
    sourceRef.current = source;
    processorRef.current = processor;

    processor.onaudioprocess = (e) => {
      const inputData = e.inputBuffer.getChannelData(0);
      
      // Calculate volume for visualizer
      let sum = 0;
      for (let i = 0; i < inputData.length; i++) {
        sum += inputData[i] * inputData[i];
      }
      const rms = Math.sqrt(sum / inputData.length);
      setVolume(v => (v * 0.8) + (rms * 0.2)); // Smooth volume
      
      // Simple VAD logic for visualizer mode
      if (rms > 0.01) {
        setMode('listening');
      } 

      const pcmBlob = createPcmBlob(inputData);
      
      sessionPromiseRef.current?.then(session => {
        session.sendRealtimeInput({ media: pcmBlob });
      });
    };

    source.connect(processor);
    processor.connect(ctx.destination);
  };

  const handleServerMessage = async (message: LiveServerMessage) => {
    const { serverContent, toolCall } = message;

    // Handle Function Calling (Lead Finalization)
    if (toolCall) {
      for (const fc of toolCall.functionCalls) {
        if (fc.name === 'finalizeLead') {
          const data = fc.args as unknown as LeadData;
          setLeadData(data);
          addLog('system', 'Lead data captured successfully.');
          
          // Respond to tool call
          sessionPromiseRef.current?.then(session => {
             session.sendToolResponse({
              functionResponses: {
                id: fc.id,
                name: fc.name,
                response: { result: "Lead saved successfully." }
              }
             });
          });
        }
      }
    }

    // Handle Audio Output
    const base64Audio = serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
    if (base64Audio && outputAudioContextRef.current) {
        setMode('speaking');
        const ctx = outputAudioContextRef.current;
        const audioBuffer = await decodeAudioData(decode(base64Audio), ctx);
        
        // Simple volume simulation for AI speaking
        setVolume(0.5); 
        
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        
        // Schedule playback
        const currentTime = ctx.currentTime;
        if (nextStartTimeRef.current < currentTime) {
            nextStartTimeRef.current = currentTime;
        }
        
        source.start(nextStartTimeRef.current);
        nextStartTimeRef.current += audioBuffer.duration;

        source.onended = () => {
             // If no more audio is scheduled soon, go to idle (approximation)
             if (ctx.currentTime >= nextStartTimeRef.current - 0.1) {
                 setMode('idle');
                 setVolume(0);
             }
        };
    }

    // Handle Transcription
    if (serverContent?.inputTranscription?.text) {
       currentInputRef.current += serverContent.inputTranscription.text;
    }
    if (serverContent?.outputTranscription?.text) {
       currentOutputRef.current += serverContent.outputTranscription.text;
    }

    // Handle Turn Complete
    if (serverContent?.turnComplete) {
       const userText = currentInputRef.current.trim();
       const aiText = currentOutputRef.current.trim();
       
       if (userText) {
           addLog('user', userText);
           currentInputRef.current = '';
       }
       if (aiText) {
           addLog('ai', aiText);
           currentOutputRef.current = '';
       }
    }
  };

  const disconnect = () => {
    // Stop tracks
    streamRef.current?.getTracks().forEach(track => track.stop());
    
    // Disconnect audio nodes
    sourceRef.current?.disconnect();
    processorRef.current?.disconnect();
    
    // Close context
    inputAudioContextRef.current?.close();
    outputAudioContextRef.current?.close();

    sessionPromiseRef.current?.then(session => {
        // session.close(); 
    });

    setConnectionState('disconnected');
    setMode('idle');
    setVolume(0);
  };

  return (
    <div className="h-screen bg-dragon-bg text-dragon-text font-sans flex flex-col items-center overflow-hidden">
      {/* Header */}
      <header className="w-full max-w-3xl flex justify-between items-center py-6 px-4 border-b border-gray-800 flex-shrink-0 z-20 bg-dragon-bg">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-dragon-primary to-dragon-highlight animate-pulse-slow"></div>
          <h1 className="text-xl tracking-wider font-light text-white">
            DRAGON <span className="text-dragon-primary font-bold">SAGE</span>
          </h1>
        </div>
        <div className="text-xs text-gray-500 uppercase tracking-widest hidden sm:block">Razorpay SDR Mode</div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-2xl flex flex-col items-center relative overflow-hidden">
        
        {apiKeyMissing ? (
            <div className="mt-10 bg-red-900/50 border border-red-500 text-red-200 p-4 rounded-lg text-center max-w-md">
                <p>API Key missing. Please check configuration.</p>
            </div>
        ) : (
            <>
                {/* Visualizer Area (Top) */}
                <div className="w-full h-40 flex-shrink-0 flex items-center justify-center relative z-10 border-b border-white/5 bg-dragon-bg/50 backdrop-blur-sm">
                    <Visualizer isActive={connectionState === 'connected'} volume={volume} mode={mode} />
                </div>

                {/* Conversation Box (Middle - Grow) */}
                <div className="flex-1 w-full overflow-y-auto p-4 space-y-4 scroll-smooth bg-black/10" id="conversation-container">
                    {logs.length === 0 && connectionState === 'connected' && (
                        <div className="text-center text-gray-500 mt-10 italic">Listening... Speak to begin.</div>
                    )}
                    {logs.length === 0 && connectionState === 'disconnected' && (
                        <div className="text-center text-gray-600 mt-10">Start the session to begin the conversation.</div>
                    )}
                    
                    {logs.map((log, i) => (
                        <div key={i} className={`flex w-full ${log.role === 'user' ? 'justify-end' : (log.role === 'ai' ? 'justify-start' : 'justify-center')}`}>
                            {log.role === 'system' ? (
                                <span className="text-xs text-gray-500 font-mono py-2 opacity-70">
                                    [{log.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}] {log.text}
                                </span>
                            ) : (
                                <div className={`max-w-[80%] rounded-2xl px-5 py-3 text-sm shadow-md 
                                    ${log.role === 'user' 
                                        ? 'bg-dragon-highlight/10 border border-dragon-highlight/30 text-dragon-text rounded-br-none' 
                                        : 'bg-dragon-primary/10 border border-dragon-primary/30 text-dragon-text rounded-bl-none'
                                    }`}>
                                    <p>{log.text}</p>
                                    <span className="text-[10px] opacity-40 block text-right mt-1">
                                        {log.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                    </span>
                                </div>
                            )}
                        </div>
                    ))}
                    <div ref={logsEndRef} />
                </div>

                {/* Lead Card Overlay */}
                {leadData && (
                    <div className="absolute top-0 left-0 w-full h-full bg-dragon-bg/95 z-50 flex justify-center items-center backdrop-blur-md animate-in fade-in duration-500 p-4">
                        <div className="w-full max-w-md flex flex-col items-center">
                            <LeadCard data={leadData} />
                            <button 
                                onClick={() => { setLeadData(null); disconnect(); }}
                                className="mt-8 px-8 py-3 bg-dragon-primary text-black font-bold rounded-full hover:bg-white transition-colors shadow-[0_0_20px_rgba(32,201,151,0.3)]"
                            >
                                Start New Session
                            </button>
                        </div>
                    </div>
                )}

                {/* Connection Controls (Bottom) */}
                <div className="w-full p-6 flex justify-center bg-dragon-bg border-t border-white/5 flex-shrink-0 z-20">
                    {connectionState === 'disconnected' || connectionState === 'error' ? (
                        <button
                            onClick={connectToGemini}
                            disabled={connectionState === 'connecting'}
                            className="group relative px-10 py-4 bg-transparent border border-dragon-primary text-dragon-primary rounded-full overflow-hidden transition-all hover:bg-dragon-primary hover:text-black focus:outline-none focus:ring-2 focus:ring-dragon-primary focus:ring-offset-2 focus:ring-offset-dragon-bg shadow-[0_0_15px_rgba(32,201,151,0.1)] hover:shadow-[0_0_25px_rgba(32,201,151,0.4)]"
                        >
                            <span className="relative z-10 flex items-center gap-2 font-bold tracking-widest text-sm">
                                {connectionState === 'connecting' ? 'SUMMONING...' : 'START CONVERSATION'}
                            </span>
                        </button>
                    ) : (
                        <button
                            onClick={disconnect}
                            className="px-8 py-3 bg-red-500/10 border border-red-500 text-red-400 rounded-full hover:bg-red-500 hover:text-white transition-all font-bold tracking-wide text-xs"
                        >
                            END SESSION
                        </button>
                    )}
                </div>
            </>
        )}
      </main>

      {/* Footer */}
      <footer className="w-full text-center py-3 text-gray-700 text-[10px] bg-dragon-bg flex-shrink-0">
        Powered by Gemini Multimodal Live API
      </footer>
    </div>
  );
};

export default App;