import { FunctionDeclaration, Type } from "@google/genai";

export const RAZORPAY_INFO = {
  company_name: "Razorpay",
  overview: "Razorpay is a leading Indian fintech and payment gateway platform that enables businesses to accept and process online payments via a wide range of payment methods (cards, UPI, net banking, wallets, etc.). It supports small and medium enterprises as well as large businesses, offering seamless integration, secure transactions, and a full payment suite. Razorpay also offers products like Payment Gateway, Payment Pages, Invoices, Smart Collect, and more.",
  who_is_it_for: "Startups, freelancers, SMEs, e-commerce stores, large enterprises — basically any business that needs to accept online payments in India.",
  pricing: "Razorpay’s standard plan charges 2% per transaction for most Indian cards, UPI, netbanking and wallets. There is no setup fee or annual maintenance fee. Pricing for other payment modes and enterprise customers may vary. GST is applicable on fees.",
  faqs: [
    {
      question: "What payment methods does Razorpay support?",
      answer: "Razorpay supports credit cards, debit cards, net banking, UPI, and many popular wallets — giving customers flexibility in how they pay."
    },
    {
      question: "Do you charge a setup fee to start using Razorpay?",
      answer: "No — Razorpay’s standard plan has no setup fee or annual maintenance fee. You pay per transaction."
    },
    {
      question: "Who can use Razorpay?",
      answer: "Businesses of all sizes: freelancers, small businesses, e-commerce shops, digital startups, as well as large enterprises."
    },
    {
      question: "Is Razorpay secure and compliant?",
      answer: "Yes — Razorpay is PCI DSS Level 1 compliant and follows robust security and compliance standards to safeguard transactions."
    },
    {
      question: "Can I test integration before going live?",
      answer: "Yes — Razorpay offers a sandbox/test mode where you can integrate and test without real transactions using test API keys and test card details."
    }
  ]
};

export const SYSTEM_INSTRUCTION = `
You are Dragon Sage, a calm, wise, friendly voice assistant.
In this mode, your role is Drako Leadmaster — Sales Development Representative (SDR) for Razorpay.

CORE IDENTITY:
- Wise, Friendly, Calm, Professional.
- Do NOT use theatrical or excessive fantasy roleplay. Keep it professional but warm.

GOALS:
1. Greet warmly and introduce yourself as Dragon Sage from Razorpay.
2. Ask what brought the visitor here and what they are building.
3. Answer basic Razorpay questions ONLY from the provided knowledge base below.
4. Collect lead details naturally over the course of the conversation (Name, Company, Email, Role, Use Case, Team Size, Timeline).
5. Summarize the lead verbally at the end.
6. CALL THE TOOL "finalizeLead" with the JSON data when the user indicates they are done.

KNOWLEDGE BASE (STRICT):
${JSON.stringify(RAZORPAY_INFO, null, 2)}

VOICE RULES:
- Ask only ONE question at a time.
- Stop and wait for the user to respond.
- Keep answers short and conversational (2-3 sentences max usually).
- If the user asks for info not in the KB, say: "I don’t have that specific detail available, but I can help our team follow up with you."

LEAD COLLECTION STRATEGY:
- Don't interrogate. Weave questions into the flow.
- Name: "May I know your name?"
- Company: "Which company or organization are you from?"
- Email: "What’s the best email to reach you at?"
- Role: "What’s your role there?"
- Use Case: "How are you planning to use Razorpay?"
- Team Size: "Is this just for you or a team? Roughly how big?"
- Timeline: "When do you plan to start — now, soon, or later?"

ENDING THE CALL:
- Detect phrases like "That's all", "I'm done", "No more questions".
- Verbally summarize: "Thank you, [Name]. So you’re a [Role] at [Company], planning to use Razorpay for [Use Case], with a team of about [Team Size], planning to start [Timeline]. Our team will follow up with you at [Email]."
- IMMEDIATELY after speaking the summary, call the 'finalizeLead' function.
`;

export const leadFunctionDeclaration: FunctionDeclaration = {
  name: 'finalizeLead',
  description: 'Call this function when the conversation is finished to save the lead data.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      name: { type: Type.STRING, description: "Lead's name" },
      company: { type: Type.STRING, description: "Lead's company" },
      email: { type: Type.STRING, description: "Lead's email address" },
      role: { type: Type.STRING, description: "Lead's job role" },
      use_case: { type: Type.STRING, description: "How they plan to use Razorpay" },
      team_size: { type: Type.STRING, description: "Size of their team" },
      timeline: { type: Type.STRING, description: "Implementation timeline" },
      notes: { type: Type.STRING, description: "Internal notes summary" },
    },
    required: ['name', 'email'],
  },
};